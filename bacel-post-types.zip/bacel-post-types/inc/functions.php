<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Direct access not allowed.
}
if ( ! function_exists( 'bacel_widgets_init' ) ) {
	function bacel_widgets_init() {
		if ( ! is_blog_installed() || ! class_exists( 'bacel_WP_Nav_Menu_Widget' ) ) {
			return;
		}

		register_widget( 'bacel_WP_Nav_Menu_Widget' );
		register_widget( 'bacel_Banner_Widget' );
		register_widget( 'bacel_Author_Area_Widget' );
		register_widget( 'bacel_Instagram_Widget' );
		register_widget( 'bacel_Static_Block_Widget' );
		register_widget( 'bacel_Twitter' );
		register_widget( 'bacel_Recent_Posts' );

		if ( bacel_woocommerce_installed() ) {
			register_widget( 'bacel_User_Panel_Widget' );
			register_widget( 'bacel_Widget_Layered_Nav' );
			register_widget( 'bacel_Widget_Sorting' );
			register_widget( 'bacel_Widget_Price_Filter' );
			register_widget( 'bacel_Widget_Search' );
			register_widget( 'bacel_Stock_Status' );
		}

	}

	add_action( 'widgets_init', 'bacel_widgets_init' );
}

if ( ! function_exists( 'bacel_compress' ) ) {
	function bacel_compress( $variable ) {
		return base64_encode( $variable );
	}
}

if ( ! function_exists( 'bacel_get_file' ) ) {
	function bacel_get_file( $variable ) {
		return file_get_contents( $variable );
	}
}

if ( ! function_exists( 'bacel_decompress' ) ) {
	function bacel_decompress( $variable ) {
		return base64_decode( $variable );
	}
}

/**
 * ------------------------------------------------------------------------------------------------
 * Add metaboxes to the product
 * ------------------------------------------------------------------------------------------------
 */
if ( ! function_exists( 'bacel_product_360_view_meta' ) ) {
	add_action( 'add_meta_boxes', 'bacel_product_360_view_meta', 50 );
	function bacel_product_360_view_meta() {
		add_meta_box( 'woocommerce-product-360-images', __( 'Product 360 View Gallery (optional)', 'bacel' ), 'bacel_360_metabox_output', 'product', 'side', 'low' );
	}
}

/**
 * ------------------------------------------------------------------------------------------------
 * Add metaboxes
 * ------------------------------------------------------------------------------------------------
 */
if ( ! function_exists( 'bacel_sguide_add_metaboxes' ) ) {
	function bacel_sguide_add_metaboxes() {
		if ( function_exists( 'bacel_get_opt' ) && ! bacel_get_opt( 'size_guides' ) ) {
			return;
		}

		// Add table metaboxes to size guide
		add_meta_box( 'bacel_sguide_metaboxes', esc_html__( 'Create/modify size guide table', 'bacel' ), 'bacel_sguide_metaboxes', 'bacel_size_guide', 'normal', 'default' );
		// Add metaboxes to product
		add_meta_box( 'bacel_sguide_dropdown_template', esc_html__( 'Choose size guide', 'bacel' ), 'bacel_sguide_dropdown_template', 'product', 'side' );
		// Add category metaboxes to size guide
		add_meta_box( 'bacel_sguide_category_template', esc_html__( 'Choose product categories', 'bacel' ), 'bacel_sguide_category_template', 'bacel_size_guide', 'side' );
		// Add hide table checkbox to size guide
		add_meta_box( 'bacel_sguide_hide_table_template', esc_html__( 'Hide size guide table', 'bacel' ), 'bacel_sguide_hide_table_template', 'bacel_size_guide', 'side' );
	}
	add_action( 'add_meta_boxes', 'bacel_sguide_add_metaboxes' );
}


if ( ! function_exists( 'bacel_get_svg' ) ) {
	function bacel_get_svg( $file ) {
		if ( ! apply_filters( 'bacel_svg_cache', true ) ) {
			return file_get_contents( $file );
		}

		$file_path = array_reverse( explode( '/', $file ) );
		$slug      = 'bacel-svg-' . $file_path[2] . '-' . $file_path[1] . '-' . $file_path[0];
		$content   = get_transient( $slug );

		if ( ! $content ) {
			$file_get_contents = file_get_contents( $file );

			if ( strstr( $file_get_contents, '<svg' ) ) {
				$content = base64_encode($file_get_contents);
				set_transient($slug, $content, apply_filters('bacel_svg_cache_time', 60 * 60 * 24 * 7));
			}
		}

		return base64_decode( $content );
	}
}

// **********************************************************************//
// ! It could be useful if you using nginx instead of apache
// **********************************************************************//
if ( ! function_exists( 'getallheaders' ) ) {
	function getallheaders() {
		$headers = array();
		foreach ( $_SERVER as $name => $value ) {
			if ( substr( $name, 0, 5 ) == 'HTTP_' ) {
				$headers[ str_replace( ' ', '-', ucwords( strtolower( str_replace( '_', ' ', substr( $name, 5 ) ) ) ) ) ] = $value;
			}
		}
		return $headers;
	}
}
add_shortcode( 'bacel_popup', 'bacel_shortcode_popup' );
add_shortcode( 'bacel_product_filters', 'bacel_product_filters_shortcode' );
add_shortcode( 'bacel_filter_categories', 'bacel_filters_categories_shortcode' );
add_shortcode( 'bacel_filters_attribute', 'bacel_filters_attribute_shortcode' );
add_shortcode( 'bacel_filters_price_slider', 'bacel_filters_price_slider_shortcode' );
add_shortcode( 'bacel_stock_status', 'bacel_stock_status_shortcode' );
add_shortcode( 'bacel_filters_orderby', 'bacel_orderby_filter_template' );
add_shortcode( 'bacel_responsive_text_block', 'bacel_shortcode_responsive_text_block' );
add_shortcode( 'bacel_compare', 'bacel_compare_shortcode' );
add_shortcode( 'bacel_slider', 'bacel_shortcode_slider' );
add_shortcode( 'bacel_title', 'bacel_shortcode_title' );
add_shortcode( 'bacel_button', 'bacel_shortcode_button' );
add_shortcode( 'bacel_instagram', 'bacel_shortcode_instagram' );
add_shortcode( 'bacel_google_map', 'bacel_shortcode_google_map' );
add_shortcode( 'bacel_portfolio', 'bacel_shortcode_portfolio' );
add_shortcode( 'bacel_blog', 'bacel_shortcode_blog' );
remove_shortcode('gallery');
add_shortcode( 'gallery', 'bacel_gallery_shortcode' );
add_shortcode( 'bacel_gallery', 'bacel_images_gallery_shortcode' );
add_shortcode( 'bacel_categories', 'bacel_shortcode_categories' );
add_shortcode( 'bacel_shortcode_products_widget', 'bacel_shortcode_products_widget' );
add_shortcode( 'bacel_counter', 'bacel_shortcode_animated_counter' );
add_shortcode( 'team_member', 'bacel_shortcode_team_member' );
add_shortcode( 'testimonials', 'bacel_shortcode_testimonials' );
add_shortcode( 'testimonial', 'bacel_shortcode_testimonial' );
add_shortcode( 'pricing_tables', 'bacel_shortcode_pricing_tables' );
add_shortcode( 'pricing_plan', 'bacel_shortcode_pricing_plan' );
add_shortcode( 'products_tabs', 'bacel_shortcode_products_tabs' );
add_shortcode( 'products_tab', 'bacel_shortcode_products_tab' );
add_shortcode( 'bacel_mega_menu', 'bacel_shortcode_mega_menu' );
add_shortcode( 'user_panel', 'bacel_shortcode_user_panel' );
add_shortcode( 'author_area', 'bacel_shortcode_author_area' );
add_shortcode( 'promo_banner', 'bacel_shortcode_promo_banner' );
add_shortcode( 'banners_carousel', 'bacel_shortcode_banners_carousel' );
add_shortcode( 'bacel_info_box', 'bacel_shortcode_info_box' );
add_shortcode( 'bacel_info_box_carousel', 'bacel_shortcode_info_box_carousel' );
add_shortcode( 'bacel_3d_view', 'bacel_shortcode_3d_view' );
add_shortcode( 'bacel_menu_price', 'bacel_shortcode_menu_price' );
add_shortcode( 'bacel_countdown_timer', 'bacel_shortcode_countdown_timer' );
add_shortcode( 'social_buttons', 'bacel_shortcode_social' );
add_shortcode( 'bacel_posts_teaser', 'bacel_shortcode_posts_teaser' );
add_shortcode( 'bacel_posts', 'bacel_shortcode_posts' );
add_shortcode( 'bacel_products', 'bacel_shortcode_products' );
add_shortcode( 'html_block', 'bacel_html_block_shortcode');
add_shortcode( 'bacel_row_divider', 'bacel_row_divider' );
add_shortcode( 'bacel_timeline', 'bacel_timeline_shortcode' );
add_shortcode( 'bacel_timeline_item', 'bacel_timeline_item_shortcode' );
add_shortcode( 'bacel_timeline_breakpoint', 'bacel_timeline_breakpoint_shortcode' );
add_shortcode( 'bacel_list', 'bacel_list_shortcode' );
add_shortcode( 'extra_menu', 'bacel_shortcode_extra_menu' );
add_shortcode( 'extra_menu_list', 'bacel_shortcode_extra_menu_list' );
add_shortcode( 'bacel_brands', 'bacel_shortcode_brands' );
add_shortcode( 'bacel_size_guide', 'bacel_size_guide_shortcode' );

function bacel_init_vc_fields() {
	if ( function_exists( 'vc_add_shortcode_param' ) ) {
		vc_add_shortcode_param( 'bacel_gradient', 'bacel_add_gradient_type' );
		vc_add_shortcode_param( 'bacel_colorpicker', 'bacel_get_colorpicker_param' );
		vc_add_shortcode_param( 'bacel_css_id', 'bacel_get_css_id_param' );
		vc_add_shortcode_param( 'bacel_dropdown', 'bacel_get_dropdown_param' );
		vc_add_shortcode_param( 'bacel_image_select', 'bacel_add_image_select_type' );
		vc_add_shortcode_param( 'bacel_responsive_size', 'bacel_get_responsive_size_param' );
		vc_add_shortcode_param( 'bacel_slider', 'bacel_get_slider_param' );
	}
}
add_action('init', 'bacel_init_vc_fields');
